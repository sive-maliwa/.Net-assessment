﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank200.Contracts
{
    public interface AccountService
    {
        void openSavingsAccount(long accountId, int amountToDeposit);
        void openCurrentAccount(long accountId);
        void withdraw(long accountId, int amountToWithdraw);
        void deposit(long accountId, int amountToDeposit);
    }
}
