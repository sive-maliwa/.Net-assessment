﻿using Bank200.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank200.Repository
{
    public class CurrentAccount : AccountService
    {
        public int overdraft { get; set; }
        public long accountID { get; set; }
        public string customerNum { get; set; }
        public int balance { get; set; }

        /*
            Here when instantiating the current account we need to make sure that the overdraft is stated as indicated in the business rule that it should not be greater than R100 000.00
            In the case the overdraft is correct we set the customerNum, balance and overdraft.
         
         */
        public CurrentAccount(string customerNumber, int iniitialDeposit, int overdraft)
        {
            if(overdraft <= 100000)
            {
                this.customerNum = customerNumber;
                this.balance = iniitialDeposit;
                this.overdraft = overdraft;
            }
            else
            {
                throw new ArgumentException("Overdraft Must be less or equal to R100 000.00");
            }

        }


        /*
         deposit:
               --> Here we model a typical bank account, that is to authenticate the transaction the caller of this method needs to know their Id
               --> We also print the balance after the transaction
         */
        public void deposit(long accountId, int amountToDeposit)
        {
            if(accountId == this.accountID)
            {
                balance += amountToDeposit;
                Console.WriteLine(this.balance);
            }
        }
        /*
         openCurrentAccount:
            --> Here we model the idea of assigning the instance (current account) an Id 

         */
        public void openCurrentAccount(long accountId)
        {
            this.accountID = accountId;
        }

        public void openSavingsAccount(long accountId, int amountToDeposit)
        {
            throw new NotImplementedException();
        }


        /*
           withdraw:
                Here we model a typical bank account, that is the account holder is expected to provide a correct account Id in order to transact on this account.\
                --> As per the business rule: We need to first calculate the allowed withdrawal which states that the amount to be withdrawn should not be greater than the sum of the balance and the overdraft.
                --> Also we print the balance after the withdrawal 
                --> Else if the business rule is not true we throw an exception.
         */
        public void withdraw(long accountId, int amountToWithdraw)
        {
            if(accountId == this.accountID)
            {
                var allowedWithdrawal = overdraft + balance;
                if(amountToWithdraw < allowedWithdrawal)
                {
                    balance -= amountToWithdraw;
                    Console.WriteLine(this.balance);
                }
                else
                {
                    throw new ArgumentException("Transaction Not Allowed: You cannot withdraw more than the sum of your balance and overdraft limit.");

                }
            }
        }
    }
}
