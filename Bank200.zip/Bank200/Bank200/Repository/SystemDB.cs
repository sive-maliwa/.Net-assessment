﻿using Bank200.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank200.Repository
{
    public static class SystemDB
    {
        public static AccountService acc1;
        public static AccountService acc2;
        public static AccountService acc3;
        public static AccountService acc4;

        static SystemDB()
        {
            /*
             * Here we create the accounts, this class knows how to create both the Savings and Current Account 
             * Also Notice we return the interface to the end consumer of our resource this is to enforce encapsulation.
             * We only want to expose the functionality and hide the implementation details to the end consumer of our resource.
            */

            acc1 = new SavingsAccount("1", 2000);
            acc2 = new SavingsAccount("2", 5000);
            acc3 = new CurrentAccount("3", 1000, 20000);
            acc4 = new CurrentAccount("4", 5000,20000);
        }
    }
}
