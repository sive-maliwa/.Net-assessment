﻿using Bank200.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank200.Repository
{
    public class SavingsAccount : AccountService
    {
        public long accountID { get; set; }
        public string customerNum { get; set; }
        public int balance { get; set; }


        /*
            At the entry point of this class we define the customer Number and the initial deposit.
               --> Note that at this point the account is only linked to the customer, we do not currently have a account id.
               --> As per business rule, this type of account is only created if the initial deposit is R1000 or more.
               --> We also assign the customer number as indicated below.
         */
        public SavingsAccount(string customerNumber, int initDeposit)
        {
            this.customerNum = customerNumber;
            if(initDeposit >= 1000)
            {
                balance = initDeposit;
            }
            else
            {
                throw new ArgumentException("Cannot open account with amount less than R1000.00");
            }
        }

        /*
         Deposit:
            --> Here we want to simulate the day to day deposit as with a bank 
               -> Customer should know their account Id when depositing to their account
               -> If the account id is correct we increment their balance by their supplied deposit.
               -> I have also Console logged the state of balance to report the correct balance after deposit
         
         */
        public void deposit(long accountId, int amountToDeposit)
        {
            if(accountId == this.accountID)
            {
                balance += amountToDeposit;
            }
            Console.WriteLine(this.balance);
            
        }

        public void openCurrentAccount(long accountId)
        {
            throw new NotImplementedException();
        }

        /*
         openSavingsAccount:
           --> We think of this method as assignment of the accountId 
           --> That is, the instance (which is an account) is assigned a id 
           --> In light of this design, the holder of the account is not obligated to deposit actual money, zero can do just fine - as we have required the R1000 when the instance was instantiated.
           --> In light of the principles of OOP, we cannot directly increase the balance, the is a method called deposit that handles this concern.
           --> This is good because should we want to change the business rule for the deposit we have one and only one method to changed.
         */
        public void openSavingsAccount(long accountId, int amountToDeposit)
        {
            this.accountID = accountId;
            deposit(accountId, amountToDeposit);
        }


        /*
         withdraw:
           --> Here we motivate the analogy of a typical bank account, that is the account holder is expected to know their account Id in order to withdraw
           --> We also implement the business rule of checking if the balance post the withdraw transaction would be R1000, if so we continue to withdraw. Else we throw an argument exception 
         
         */
        public void withdraw(long accountId, int amountToWithdraw)
        {
            
            var postTransactionbalance = balance - amountToWithdraw;
            if(accountId == this.accountID)
            {
                if (postTransactionbalance > 1000)
                {
                    balance = balance - amountToWithdraw;
                    Console.WriteLine(this.balance);
                }
                else
                {
                    throw new ArgumentException("Cannot withdraw an amount that will leave a balance less than R 1000.00");
                }
            }
        }

    }

}
