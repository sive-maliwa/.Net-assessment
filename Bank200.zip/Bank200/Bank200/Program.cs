﻿using Bank200.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank200
{
    class Program
    {
        static void Main(string[] args)
        {
            //SystemDB.acc1.openSavingsAccount(1, 3000);
            //SystemDB.acc1.deposit(1, 3000);
            //SystemDB.acc1.withdraw(1, 7500);
            SystemDB.acc3.openCurrentAccount(1);
            SystemDB.acc3.deposit(1, 2000); //R11k
            SystemDB.acc3.withdraw(1, 17000); // true case : R6k
            //SystemDB.acc3.
            var item = 1;
        }
    }
}
